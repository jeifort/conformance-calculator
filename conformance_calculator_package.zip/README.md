
# Conformance Calculator

This is a simple web-based tool to calculate how many minutes you need to give back to reach 100% conformance.

## How to Host on GitHub Pages

1. Create a new repository on GitHub (make it public).
2. Upload the `index.html` file from this ZIP.
3. Go to **Settings** → **Pages**.
4. Under **Source**, select `main` branch and `/root` folder.
5. Click **Save**.
6. Wait 2–5 minutes. Your site will be live at:
   ```
   https://yourusername.github.io/repository-name/
   ```

## Features
- Enter scheduled minutes and current conformance percentage.
- Click **Calculate** to see minutes to give back.

Enjoy!
